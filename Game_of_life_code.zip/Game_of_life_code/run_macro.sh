#!/bin/sh  


nohup python game_of_life.py --number_of_random 0 --number_of_perturb_glider 0 --number_of_glider 2 --Sample_Iter 50000 --T 200000 &
