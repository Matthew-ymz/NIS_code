import numpy as np
import torch
from torch import nn
from torch.autograd.functional import jacobian
from sklearn.neighbors import KernelDensity


def kde_density(X):
    kde = KernelDensity(kernel='gaussian', bandwidth=0.05, atol=0.2).fit(X.cpu().data.numpy())
    log_density = kde.score_samples(X.cpu().data.numpy())
    return log_density, kde

def to_weights(log_w, temperature=1):
    # Normalize log_w and obtain the weights
    logsoft = nn.LogSoftmax(dim = 0)
    weights = torch.exp(logsoft(log_w/temperature))
    return weights

def approx_ei_cnn(dynamics, state, latent, latent_p, device, num_samples=1000, L=100):
    ei_layer = 0
    # sampling x on the space [-L,L]^n, n is the number of samples
    xx = L * 2 * (torch.rand(num_samples, latent_p.size()[1], latent_p.size()[2]*latent_p.size()[3], device=device) - 1 / 2)
    ll = torch.nn.L1Loss(reduction='none')
    for layer in range(state.size()[1]):
        scale = latent.size()[2] * latent.size()[3]
        log_density, _ = kde_density(latent[:,layer,:,:].reshape(latent.size()[0], -1))
        log_rho = - scale * torch.log(2.0*torch.from_numpy(np.array(L)))  # Uniform distribution probability distribution
        logp = log_rho - log_density  #The difference between two probability distributions
        weights = to_weights(logp) * state.size()[0]
        weights = weights.to(device)
        weights = weights.unsqueeze(1)
        new_weights = weights.clone()
        for iter in range(scale-1):
            new_weights = torch.cat((new_weights,weights),1)
        mae1 = ll(state[:,layer,:,:].reshape(state.size()[0], -1), latent_p[:,layer,:,:].reshape(latent_p.size()[0], -1)) * new_weights
        sigmas = mae1.mean(axis=0)
        sigmas_matrix = torch.diag(sigmas)     #sigma_matrix: the inverse of the covariance matrix of the gaussian distribution on Y: dim: y_dim * y_dim
        ei = approx_ei(xx, scale, scale, sigmas_matrix.data, layer, lambda x: (dynamics(x.reshape(1, latent_p.size()[1], latent_p.size()[2], latent_p.size()[3])) + x.reshape(1, latent_p.size()[1], latent_p.size()[2], latent_p.size()[3])).reshape(latent_p.size()[1], -1), L=100, easy=True, device=device)
        ei_layer += ei[0]
    return ei_layer/state.size()[1]

# EI calculation function
def approx_ei(xx, input_size, output_size, sigmas_matrix, idx, func, L, easy=True, device=None):
    # Approximated calculation program for various EI (Dimensionally averaged EI, Eff, and EI) and related 
    # Quantities on Gaussian neural network
    # input variables：
    #input_size: the dimension of input to the func (neural network) (x_dim)
    #output_size: the dimension of the output of the func (neural network) (y_dim)
    #sigma_matrix: the inverse of the covariance matrix of the gaussian distribution on Y: dim: y_dim * y_dim
    #func: any function, can be a neural network
    #L the linear size of the box of x on one side (-L,L)
    
    # output variables：
    # d_EI： dimensionally averaged EI
    # eff： EI coefficient （EI/H_max)
    # EI: EI, effective information (common)
    # term1: - Shannon Entropy
    # term2: EI+Shannon Entropy (determinant of Jacobian)
    # -np.log(rho): - ln(\rho), where \rho=(2L)^{-output_size} is the density of uniform distribution
    
    rho = 1/(2*L)**input_size #the density of X even distribution
    
    dett = 1.0
    if easy:
        dd = torch.diag(sigmas_matrix)
        dett = torch.log(dd).sum()
    else:
        # dett = np.log(np.linalg.det(sigmas_matrix_np))
        dett = torch.log(torch.linalg.det(sigmas_matrix))
    term1 = - (output_size + output_size * np.log(2 * np.pi) + dett) / 2
    
    dets = 0
    logdets = 0

    # iterate all samples of x
    for i in range(xx.size()[0]):
        jac = jacobian(func, xx[i, :, :])[idx, :, idx, :]  # use pytorch's jacobian function to obtain jacobian matrix
        det = torch.abs(torch.det(jac))  # calculate the determinate of the jacobian matrix
        dets += det.item()
        if det != 0:
            logdets += torch.log(det).item()  # log jacobian
        else:
            # if det==0 then, it becomes a gaussian integration
            logdet = -(output_size + output_size * np.log(2 * np.pi) + dett)
            logdets += logdet.item()

    int_jacobian = logdets / xx.size()[0]  # take average of log jacobian

    term2 = output_size * np.log(2 * L) + int_jacobian  # derive the 2nd term

    if dets == 0:
        term2 = - term1
    EI = max(term1 + term2, 0)
    if torch.is_tensor(EI):
        EI = EI.item()
    eff = EI / (output_size * np.log(2 * L))
    d_EI = EI / output_size

    return d_EI, eff, EI, term1, term2, -np.log(rho)
